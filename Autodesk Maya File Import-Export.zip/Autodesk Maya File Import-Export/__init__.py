import bpy
import os
import subprocess
import tempfile
import logging
import sys
import platform
import traceback
import math
from bpy_extras.io_utils import ExportHelper, ImportHelper
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator, AddonPreferences, FileHandler

# 设置缓存目录
cache_dir = os.path.join(os.path.expanduser("~"), "Documents", "blender_maya_cache")
os.makedirs(cache_dir, exist_ok=True)

bl_info = {
    "name": "Autodesk Maya File Import-Export",
    "author": "475519905",
    "version": (2, 0, 1),
    "blender": (4, 2, 0),
    "location": "File > Import-Export > Maya (.mb, .ma)",
    "description": "Import and Export Maya (.mb, .ma) files using Maya's Python environment, with filtering and drag-and-drop support.",
    "category": "Import-Export",
    "support": "COMMUNITY",
    "warning": "Must select a valid Maya Python path in preferences to use normally!",
    "doc_url": "https://space.bilibili.com/34368968",
    "tracker_url": "https://github.com/475519905/blender-Import-export-cinema4d-file/tree/main",
}

# 设置日志
log_file = os.path.join(os.path.expanduser("~"), "Documents", "blender_maya_log.txt")
# --- Ensure log directory exists ---
log_dir = os.path.dirname(log_file)
try:
    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
        # print(f"Created log directory: {log_dir}") # Logger not set up yet
except OSError as e:
    # print(f"Error creating log directory {log_dir}: {e}. Logging may fail.")
    pass
# ---------------------------------
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    filename=log_file,
                    filemode='a')
logger = logging.getLogger(__name__)
if log_dir and not os.path.exists(log_dir): # Log if creation might have been an issue
    logger.info(f"Log directory {log_dir} might not have been created if an error occurred earlier.")
else:
    logger.info(f"Logging to: {log_file}")

class MayaPreferences(AddonPreferences):
    bl_idname = __name__

    maya_python_path: StringProperty(
        name="Maya Python Path",
        description="Path to Maya's Python executable (mayapy.exe)",
        subtype='FILE_PATH',
        default="C:\\\\Program Files\\\\Autodesk\\\\Maya2025\\\\bin\\\\mayapy.exe" # Default for Windows
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "maya_python_path")
        # layout.label(text="Ensure this path points to 'mayapy.exe' (or equivalent).")


class ExportMaya(Operator, ExportHelper):
    bl_idname = "export_scene.maya"
    bl_label = "Export Maya File"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".mb;.ma"
    filter_glob: StringProperty(default="*.mb;*.ma", options={'HIDDEN'})

    export_models: BoolProperty(name="Models", description="Export mesh objects", default=True)
    export_lights: BoolProperty(name="Lights", description="Export light objects", default=True)
    export_cameras: BoolProperty(name="Cameras", description="Export camera objects", default=True)
    export_splines: BoolProperty(name="Splines", description="Export curve/spline objects", default=True)
    export_animations: BoolProperty(name="Animations", description="Export animations", default=True)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        grid = layout.grid_flow(columns=2, align=True)
        grid.prop(self, "export_models", icon='MESH_DATA', toggle=True)
        grid.prop(self, "export_lights", icon='LIGHT', toggle=True)
        grid.prop(self, "export_cameras", icon='CAMERA_DATA', toggle=True)
        grid.prop(self, "export_splines", icon='CURVE_DATA', toggle=True)
        grid.prop(self, "export_animations", icon='ANIM', toggle=True)

    def execute(self, context):
        logger.info("Initiating Maya export operation.")
        return self.export_maya(context, self.filepath)

    def export_maya(self, context, filepath):
        preferences = context.preferences.addons[__name__].preferences
        maya_python_path = preferences.maya_python_path

        if not maya_python_path or not os.path.exists(maya_python_path):
            logger.error(f"Maya Python executable not found at: {maya_python_path}. Please set it in Addon Preferences.")
            self.report({'ERROR'}, "Maya Python executable path not set or invalid. Check Addon Preferences.")
            return {'CANCELLED'}

        with tempfile.TemporaryDirectory(prefix="blender_maya_export_") as temp_dir:
            fbx_path = os.path.join(temp_dir, "temp_export.fbx")
            logger.info(f"Intermediate FBX will be exported to: {fbx_path}")
            
            try:
                original_selection = bpy.context.selected_objects[:]
                original_active = bpy.context.view_layer.objects.active
                
                bpy.ops.object.select_all(action='DESELECT')
                export_objects_count = 0
                for obj in bpy.context.scene.objects: # Consider visible/renderable objects if needed
                    obj.select_set(False) 
                    should_select = False
                    if obj.type == 'MESH' and self.export_models: should_select = True
                    elif obj.type == 'LIGHT' and self.export_lights: should_select = True
                    elif obj.type == 'CAMERA' and self.export_cameras: should_select = True
                    elif obj.type == 'CURVE' and self.export_splines: should_select = True
                    elif obj.type == 'ARMATURE' and (self.export_models or self.export_animations): should_select = True
                    
                    if should_select:
                        obj.select_set(True)
                        export_objects_count += 1
                
                if export_objects_count == 0:
                    self.report({'WARNING'}, "No objects match export filters. Nothing exported to FBX.")
                    logger.warning("No objects matched export filters for FBX export.")
                    # Restore selection before returning
                    bpy.ops.object.select_all(action='DESELECT')
                    if original_active and original_active.name in bpy.context.scene.objects:
                        bpy.context.view_layer.objects.active = original_active
                    for obj_ref in original_selection:
                        if obj_ref and obj_ref.name in bpy.context.scene.objects: obj_ref.select_set(True)
                    return {'CANCELLED'}

                logger.info(f"Exporting {export_objects_count} objects to FBX based on filters.")
                bpy.ops.export_scene.fbx(
                    filepath=fbx_path,
                    use_selection=True,
                    path_mode='COPY', # Embeds textures if possible, or copies them
                    bake_anim=self.export_animations
                )
                logger.info("FBX export from Blender completed.")

                # Restore original Blender selection
                bpy.ops.object.select_all(action='DESELECT')
                if original_active and original_active.name in bpy.context.scene.objects:
                    bpy.context.view_layer.objects.active = original_active
                for obj_ref in original_selection:
                    if obj_ref and obj_ref.name in bpy.context.scene.objects: obj_ref.select_set(True)

            except Exception as e:
                logger.error(f"FBX export from Blender failed: {str(e)}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                self.report({'ERROR'}, f"FBX export from Blender failed. See log: {log_file}")
                return {'CANCELLED'}

            # Maya Python script to import FBX and save as .mb/.ma
            maya_script = f"""
import maya.standalone
import maya.cmds as cmds
import sys
import os
import traceback

def print_and_flush(message):
    print(message)
    sys.stdout.flush()
    sys.stderr.flush()

print_and_flush("[MAYA_EXPORT_LOG] Maya Script Start (Export Process)")
try:
    maya.standalone.initialize(name='python')
    print_and_flush("[MAYA_EXPORT_LOG] Maya Standalone Initialized.")
    
    fbx_to_import = r"{fbx_path}"
    target_maya_file = r"{filepath}"
    
    print_and_flush(f"[MAYA_EXPORT_LOG] Importing FBX: {{fbx_to_import}}")
    if not os.path.exists(fbx_to_import):
        print_and_flush(f"[MAYA_EXPORT_ERROR] FBX file not found: {{fbx_to_import}}")
        sys.exit(1)

    # It's good practice to load fbxmaya.mll if not already loaded
    if not cmds.pluginInfo("fbxmaya.mll", query=True, loaded=True):
        print_and_flush("[MAYA_EXPORT_LOG] Loading fbxmaya.mll plugin.")
        cmds.loadPlugin("fbxmaya.mll")
        print_and_flush("[MAYA_EXPORT_LOG] fbxmaya.mll loaded.")

    # Create new scene before import if desired, or import into current (empty) one
    cmds.file(new=True, force=True)
    print_and_flush("[MAYA_EXPORT_LOG] New Maya scene created.")

    cmds.file(fbx_to_import, i=True, type="FBX", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace="BLENDER")
    print_and_flush("[MAYA_EXPORT_LOG] FBX imported into Maya.")
    
    file_type = "mayaBinary" if target_maya_file.lower().endswith(".mb") else "mayaAscii"
    print_and_flush(f"[MAYA_EXPORT_LOG] Saving to Maya file: {{target_maya_file}} as type: {{file_type}}")
    
    cmds.file(rename=target_maya_file)
    save_result = cmds.file(save=True, type=file_type)
    print_and_flush(f"[MAYA_EXPORT_LOG] Maya file saved: {{save_result}}")
    
    if not os.path.exists(target_maya_file) or os.path.getsize(target_maya_file) == 0:
        print_and_flush(f"[MAYA_EXPORT_ERROR] Target Maya file not created or empty: {{target_maya_file}}")
        sys.exit(1)
    print_and_flush(f"[MAYA_EXPORT_LOG] Successfully exported to {{target_maya_file.lower().split('.')[-1].upper()}} format.")

except Exception as e_maya:
    print_and_flush(f"[MAYA_EXPORT_ERROR] Error during Maya processing: {{str(e_maya)}}")
    traceback.print_exc(file=sys.stderr)
    sys.stderr.flush()
    sys.exit(1)
finally:
    if 'maya.standalone' in sys.modules:
        maya.standalone.uninitialize()
        print_and_flush("[MAYA_EXPORT_LOG] Maya Standalone Uninitialized.")

print_and_flush("[MAYA_EXPORT_LOG] Maya Script End (Export Process)")
"""
            maya_script_path = os.path.join(temp_dir, "blender_to_maya_export_script.py")
            with open(maya_script_path, 'w', encoding='utf-8') as f:
                f.write(maya_script)

            logger.info(f"Running Maya script for final export: {maya_script_path}")
            try:
                # Basic environment, mayapy should find its own modules if path is correct
                run_env = os.environ.copy() 
                # Ensure MAYA_LOCATION is set if script relies on it implicitly for plugins etc.
                maya_bin_dir = os.path.dirname(maya_python_path)
                maya_root_dir = os.path.dirname(maya_bin_dir) # common assumption MayaXXX/bin/mayapy
                run_env['MAYA_LOCATION'] = maya_root_dir

                result = subprocess.run([maya_python_path, maya_script_path], 
                                     check=False, # Check manually
                                     capture_output=True, 
                                     text=True,
                                     env=run_env,
                                     encoding='utf-8')
                
                stdout_s = result.stdout.strip() if result.stdout else ""
                stderr_s = result.stderr.strip() if result.stderr else ""
                if stdout_s: logger.info(f"Maya Export Script STDOUT:\n{stdout_s}")
                if stderr_s: logger.error(f"Maya Export Script STDERR:\n{stderr_s}")

                if result.returncode != 0 or "[MAYA_EXPORT_ERROR]" in stdout_s or "[MAYA_EXPORT_ERROR]" in stderr_s:
                    logger.error(f"Running Maya export script failed. RC: {result.returncode}")
                    self.report({'ERROR'}, f"Maya script execution failed. See log: {log_file}")
                    return {'CANCELLED'}
            except Exception as e_run_script:
                logger.error(f"Error running Maya export script: {str(e_run_script)}")
                logger.error(f"Traceback: {traceback.format_exc()}")
                self.report({'ERROR'}, f"Failed to run Maya script. See log: {log_file}")
                return {'CANCELLED'}

        logger.info(f"Export to Maya file completed: {filepath}")
        self.report({'INFO'}, f"Exported successfully to: {filepath}")
        return {'FINISHED'}


class ImportMaya(Operator, ImportHelper):
    bl_idname = "import_scene.maya"
    bl_label = "Import Maya File"
    bl_description = "Import a Maya (.mb or .ma) file via FBX conversion"

    filename_ext = ".mb;.ma"
    filter_glob: StringProperty(default="*.mb;*.ma", options={'HIDDEN'})

    import_models: BoolProperty(name="Models", description="Import mesh objects", default=True)
    import_lights: BoolProperty(name="Lights", description="Import light objects", default=True)
    import_cameras: BoolProperty(name="Cameras", description="Import camera objects", default=True)
    import_splines: BoolProperty(name="Splines", description="Import curve/spline objects", default=True)
    import_animations: BoolProperty(name="Animations", description="Import and apply animations", default=True)
    import_materials: BoolProperty(name="Materials", description="Assign materials to imported objects", default=True)
    import_armatures: BoolProperty(name="Armatures", description="Import skeleton/bone structures", default=True)
    apply_rotation: BoolProperty(name="Maya Axis", description="Rotate imported objects 180 degrees around X-axis", default=False)

    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(columns=2, align=True)
        grid.prop(self, "import_models", icon='MESH_DATA', toggle=True)
        grid.prop(self, "import_lights", icon='LIGHT', toggle=True)
        grid.prop(self, "import_cameras", icon='CAMERA_DATA', toggle=True)
        grid.prop(self, "import_splines", icon='CURVE_DATA', toggle=True)
        grid.prop(self, "import_animations", icon='ANIM', toggle=True)
        grid.prop(self, "import_materials", icon='MATERIAL', toggle=True)
        grid.prop(self, "import_armatures", icon='ARMATURE_DATA', toggle=True)
        layout.prop(self, "apply_rotation")

    def execute(self, context):
        mb_file_path = self.filepath
        logger.info(f"Initiating Maya import for: {mb_file_path}")

        if not mb_file_path or not (mb_file_path.lower().endswith(".mb") or mb_file_path.lower().endswith(".ma")):
            self.report({'ERROR'}, "Invalid file path or extension. Must be .mb or .ma")
            return {'CANCELLED'}

        preferences = context.preferences.addons[__name__].preferences
        mayapy_exe = preferences.maya_python_path
        if not mayapy_exe or not os.path.exists(mayapy_exe):
            logger.error(f"Maya Python executable not found: {mayapy_exe}. Check Addon Preferences.")
            self.report({'ERROR'}, "Maya Python executable not found. Check Addon Preferences.")
            return {'CANCELLED'}

        base_name_ext = os.path.basename(mb_file_path)
        base_name, _ = os.path.splitext(base_name_ext)
        fbx_file_name = f"blender_maya_import_{base_name}.fbx"
        fbx_file_path = os.path.join(cache_dir, fbx_file_name)

        existing_object_names = {obj.name for obj in bpy.context.scene.objects}
        
        maya_bin_path = os.path.dirname(mayapy_exe)
        maya_location = os.path.dirname(maya_bin_path)

        maya_env = os.environ.copy()
        maya_env["MAYA_LOCATION"] = maya_location
        maya_env["PATH"] = f"{maya_bin_path}{os.pathsep}{maya_env.get('PATH', '')}"
        python_site_packages = os.path.join(maya_location, 'Python', 'Lib', 'site-packages')
        maya_env["PYTHONPATH"] = f"{python_site_packages}{os.pathsep}{maya_env.get('PYTHONPATH', '')}"
        
        # Simplified plugin/script paths, may need adjustment for complex Maya setups or USD
        maya_plugin_path = os.path.join(maya_location, 'plug-ins')
        maya_script_path = os.path.join(maya_location, 'scripts')

        # Add common USD plugin paths if they exist
        maya_usd_plugin_path = os.path.join(maya_location, 'MayaUSD', 'plugin', 'plug-ins')
        if os.path.exists(maya_usd_plugin_path):
            maya_plugin_path += f"{os.pathsep}{maya_usd_plugin_path}"
        
        usd_script_path = os.path.join(maya_location, 'MayaUSD', 'plugin', 'scripts')
        if os.path.exists(usd_script_path):
            maya_script_path += f"{os.pathsep}{usd_script_path}"
            
        maya_env["MAYA_PLUG_IN_PATH"] = maya_plugin_path
        maya_env["MAYA_SCRIPT_PATH"] = maya_script_path
        maya_env["PYTHONIOENCODING"] = "UTF-8"
        
        for key_prefix in ["PXR_", "OIIO_", "MATERIALX_"]: # Clean known conflicting env vars
            for k in list(maya_env.keys()): # Iterate over a copy for safe deletion
                 if k.startswith(key_prefix): del maya_env[k]

        maya_import_script_content = f"""
import sys, os, traceback
def print_and_flush(msg): print(msg); sys.stdout.flush(); sys.stderr.flush()
print_and_flush("[MAYA_IMPORT_LOG] Maya Script Start (Import Process)")
try:
    import maya.standalone
    maya.standalone.initialize(name='python')
    print_and_flush("[MAYA_IMPORT_LOG] Maya Standalone Initialized.")
    import maya.cmds as cmds
    print_and_flush("[MAYA_IMPORT_LOG] maya.cmds imported.")

    if not cmds.pluginInfo("fbxmaya.mll", query=True, loaded=True):
        print_and_flush("[MAYA_IMPORT_LOG] Loading fbxmaya.mll plugin.")
        cmds.loadPlugin("fbxmaya.mll")
    print_and_flush("[MAYA_IMPORT_LOG] fbxmaya.mll is loaded.")

    mb_input_path = r'{mb_file_path}'
    fbx_output_path = r'{fbx_file_path}'
    print_and_flush(f"[MAYA_IMPORT_LOG] Source: {{mb_input_path}}, Target FBX: {{fbx_output_path}}")

    if not os.path.exists(mb_input_path):
        print_and_flush(f"[MAYA_IMPORT_ERROR] Input Maya file not found: {{mb_input_path}}")
        sys.exit(1)

    cmds.file(mb_input_path, open=True, force=True)
    print_and_flush("[MAYA_IMPORT_LOG] Maya file opened.")
    
    # FBX Export settings - ensure options are robust for geometry, anim, materials
    # cmds.FBXResetExport() # Good practice to reset to defaults
    # Example options:
    # cmds.FBXExportUpAxis("y")
    # cmds.FBXExportFileVersion("FBX202000") # Or a version compatible with Blender's importer
    # cmds.FBXExportEmbeddedTextures(v=False) # Blender handles textures better from path_mode='COPY'
    # cmds.FBXExportAnimationOnly(v=False) # Export geometry too
    # cmds.FBXExportReferencedAssetsContent(v=True) # Include referenced content

    cmds.file(fbx_output_path, exportAll=True, type="FBX export", force=True, options="FBX202000") # Using a common FBX version
    print_and_flush("[MAYA_IMPORT_LOG] FBX export command issued.")

    if not os.path.exists(fbx_output_path) or os.path.getsize(fbx_output_path) == 0:
        print_and_flush(f"[MAYA_IMPORT_ERROR] FBX export failed or file is empty: {{fbx_output_path}}")
        sys.exit(1)
    print_and_flush(f"[MAYA_IMPORT_LOG] FBX file exported: {{fbx_output_path}} (Size: {{os.path.getsize(fbx_output_path)}} B)")

except Exception as e:
    print_and_flush(f"[MAYA_IMPORT_ERROR] Maya processing failed: {{e}}")
    traceback.print_exc(file=sys.stderr)
    sys.exit(1)
finally:
    if 'maya.standalone' in sys.modules:
        maya.standalone.uninitialize()
        print_and_flush("[MAYA_IMPORT_LOG] Maya Standalone Uninitialized.")
print_and_flush("[MAYA_IMPORT_LOG] Maya Script End (Import Process)")
"""
        temp_script_path = os.path.join(cache_dir, "temp_maya_to_fbx_for_blender_import.py")
        with open(temp_script_path, 'w', encoding='utf-8') as f: f.write(maya_import_script_content)
        
        logger.info(f"Executing Maya to FBX conversion script: {temp_script_path}")
        try:
            result_maya = subprocess.run(
                [mayapy_exe, temp_script_path], capture_output=True, text=True,
                encoding='utf-8', env=maya_env, cwd=maya_bin_path, check=False
            )
            s_out = result_maya.stdout.strip() if result_maya.stdout else ""
            s_err = result_maya.stderr.strip() if result_maya.stderr else ""
            if s_out: logger.info(f"Maya->FBX Script STDOUT:\n{s_out}")
            if s_err: logger.error(f"Maya->FBX Script STDERR:\n{s_err}")

            if result_maya.returncode != 0 or "[MAYA_IMPORT_ERROR]" in s_out or "[MAYA_IMPORT_ERROR]" in s_err:
                logger.error(f"Maya to FBX script failed. RC: {result_maya.returncode}")
                self.report({'ERROR'}, f"Maya to FBX conversion failed. See log: {log_file}")
                return {'CANCELLED'}
        except Exception as e_run:
            logger.error(f"Error running Maya to FBX script: {e_run}\n{traceback.format_exc()}")
            self.report({'ERROR'}, f"Failed to run Maya to FBX script. See log: {log_file}")
            return {'CANCELLED'}
        finally:
            if os.path.exists(temp_script_path): os.remove(temp_script_path)

        if not os.path.exists(fbx_file_path) or os.path.getsize(fbx_file_path) == 0:
            logger.error(f"Intermediate FBX file missing or empty: {fbx_file_path}")
            self.report({'ERROR'}, "Maya conversion did not produce a valid FBX file.")
            return {'CANCELLED'}
            
        try:
            logger.info(f"Importing generated FBX into Blender: {fbx_file_path}")
            bpy.ops.object.select_all(action='DESELECT')
            bpy.ops.import_scene.fbx(filepath=fbx_file_path, global_scale=100.0, use_custom_normals=True) # Added custom normals
            logger.info("FBX imported into Blender.")

            imported_objects = {obj for obj in bpy.context.scene.objects if obj.name not in existing_object_names}
            logger.info(f"Identified {len(imported_objects)} newly imported Blender objects.")

            if imported_objects:
                bpy.ops.object.select_all(action='DESELECT')
                active_set = False
                for obj in imported_objects:
                    obj.select_set(True)
                    if not active_set:
                        bpy.context.view_layer.objects.active = obj
                        active_set = True
                
                # 根据选项应用X轴180度旋转
                if self.apply_rotation:
                    for obj in imported_objects:
                        obj.rotation_euler.x = 3.14159  # 180度 = π弧度
                    logger.info("已应用X轴180度旋转。")
                
                bpy.ops.object.select_all(action='DESELECT')

                # Asset Filtering
                processed_for_deletion = set()
                if not self.import_models: 
                    processed_for_deletion.update(self._filter_objects_by_type(imported_objects, 'MESH', keep=False))
                if not self.import_lights: 
                    processed_for_deletion.update(self._filter_objects_by_type(imported_objects, 'LIGHT', keep=False))
                if not self.import_cameras: 
                    processed_for_deletion.update(self._filter_objects_by_type(imported_objects, 'CAMERA', keep=False))
                if not self.import_splines: 
                    processed_for_deletion.update(self._filter_objects_by_type(imported_objects, 'CURVE', keep=False))
                # Consider Armatures with models:
                if not self.import_armatures: # 如果不导入骨骼
                    processed_for_deletion.update(self._filter_objects_by_type(imported_objects, 'ARMATURE', keep=False))
                elif not self.import_models and self.import_animations: # 如果不导入模型但要导入动画
                    logger.info("Models are off, but animations are on. Armatures will be kept if present.")

                remaining_after_deletion = imported_objects - processed_for_deletion
                if not self.import_animations and remaining_after_deletion:
                    self._filter_animations_from_objects(remaining_after_deletion, keep=False)
                if not self.import_materials and remaining_after_deletion:
                    self._filter_materials_from_objects(remaining_after_deletion, keep=False)
            
            bpy.ops.object.select_all(action='DESELECT')

        except Exception as e_blender:
            logger.error(f"Blender FBX import or post-processing failed: {e_blender}\n{traceback.format_exc()}")
            self.report({'ERROR'}, f"Blender FBX import/processing error. See log: {log_file}")
            return {'CANCELLED'}
        finally:
            if os.path.exists(fbx_file_path): 
                logger.info(f"Cleaning up intermediate FBX: {fbx_file_path}")
                try: os.remove(fbx_file_path)
                except OSError as e_rem: logger.warning(f"Could not remove {fbx_file_path}: {e_rem}")

        logger.info(f"Maya import process completed for: {mb_file_path}")
        self.report({'INFO'}, f"Successfully imported: {mb_file_path}")
        return {'FINISHED'}

    def _filter_objects_by_type(self, objects_to_check, obj_type, keep=True):
        bpy.ops.object.select_all(action='DESELECT')
        targeted_objects = set()
        for obj in objects_to_check:
            if obj and obj.name in bpy.context.scene.objects and obj.type == obj_type:
                obj.select_set(True)
                targeted_objects.add(obj)
        
        if not keep and targeted_objects:
            logger.info(f"Filtering: Deleting {len(targeted_objects)} objects of type {obj_type}.")
            bpy.ops.object.delete()
            return targeted_objects # Return what was deleted
        elif keep and targeted_objects:
             logger.info(f"Filtering: Keeping {len(targeted_objects)} objects of type {obj_type}.")
        bpy.ops.object.select_all(action='DESELECT')
        return targeted_objects if not keep else set() # Return deleted if not keep, else empty set

    def _filter_animations_from_objects(self, objects_to_check, keep=True):
        if not keep:
            cleared_count = 0
            for obj in objects_to_check:
                if obj and obj.name in bpy.context.scene.objects and obj.animation_data:
                    obj.animation_data_clear()
                    cleared_count += 1
            if cleared_count > 0: logger.info(f"Filtering: Cleared animation data from {cleared_count} objects.")

    def _filter_materials_from_objects(self, objects_to_check, keep=True):
        if not keep:
            cleared_count = 0
            for obj in objects_to_check:
                if obj and obj.name in bpy.context.scene.objects and obj.data and hasattr(obj.data, 'materials'):
                    if obj.data.materials: obj.data.materials.clear(); cleared_count += 1
            if cleared_count > 0: logger.info(f"Filtering: Cleared material slots from {cleared_count} objects.")


class InvokeImportMaya(Operator):
    bl_idname = "invoke_import_scene.maya"
    bl_label = "Import Autodesk Maya File Options"
    bl_options = {'REGISTER', 'UNDO'}
    filepath: StringProperty(subtype='FILE_PATH')
    import_models: BoolProperty(name="Models", default=True)
    import_lights: BoolProperty(name="Lights", default=True)
    import_cameras: BoolProperty(name="Cameras", default=True)
    import_splines: BoolProperty(name="Splines", default=True)
    import_animations: BoolProperty(name="Animations", default=True)
    import_materials: BoolProperty(name="Materials", default=True)
    import_armatures: BoolProperty(name="Armatures", description="Import skeleton/bone structures", default=True)
    apply_rotation: BoolProperty(name="Maya Axis", description="Rotate imported objects 180 degrees around X-axis", default=True)

    def invoke(self, context, event):
        if not self.filepath or not os.path.exists(self.filepath) or \
           not (self.filepath.lower().endswith(".mb") or self.filepath.lower().endswith(".ma")):
            self.report({'ERROR'}, "Invalid Maya file (.mb or .ma) for drag-and-drop.")
            return {'CANCELLED'}
        logger.info(f"Drag-and-drop for Maya file: {self.filepath}. Opening options dialog.")
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(columns=2, align=True)
        grid.prop(self, "import_models", icon='MESH_DATA', toggle=True)
        grid.prop(self, "import_lights", icon='LIGHT', toggle=True)
        grid.prop(self, "import_cameras", icon='CAMERA_DATA', toggle=True)
        grid.prop(self, "import_splines", icon='CURVE_DATA', toggle=True)
        grid.prop(self, "import_animations", icon='ANIM', toggle=True)
        grid.prop(self, "import_materials", icon='MATERIAL', toggle=True)
        grid.prop(self, "import_armatures", icon='ARMATURE_DATA', toggle=True)
        layout.prop(self, "apply_rotation")

    def execute(self, context):
        logger.info(f"Executing Maya import for: {self.filepath} (drag-and-drop) with options.")
        try:
            bpy.ops.import_scene.maya(
                'EXEC_DEFAULT', filepath=self.filepath,
                import_models=self.import_models, import_lights=self.import_lights,
                import_cameras=self.import_cameras, import_splines=self.import_splines,
                import_animations=self.import_animations, import_materials=self.import_materials,
                import_armatures=self.import_armatures, apply_rotation=self.apply_rotation
            )
            return {'FINISHED'}
        except Exception as e:
            logger.error(f"Drag-and-drop import_scene.maya call failed: {e}\n{traceback.format_exc()}")
            self.report({'ERROR'}, f"Drag-and-drop Maya import failed: {e}. See log.")
            return {'CANCELLED'}

class ImportMayaFileHandler(FileHandler):
    bl_idname = "IMPORT_SCENE_FH_maya"
    bl_label = "Maya Importer File Handler"
    bl_import_operator = "invoke_import_scene.maya"
    bl_file_extensions = ".mb;.ma"
    @classmethod
    def poll_drop(cls, context): return context.area.type in {'VIEW_3D', 'OUTLINER'}

def menu_func_export(self, context):
    self.layout.operator(ExportMaya.bl_idname, text="Autodesk Maya (.mb, .ma)")

def menu_func_import(self, context):
    self.layout.operator(ImportMaya.bl_idname, text="Autodesk Maya (.mb, .ma)")

def register():
    bpy.utils.register_class(MayaPreferences)
    bpy.utils.register_class(ExportMaya)
    bpy.utils.register_class(ImportMaya)
    bpy.utils.register_class(InvokeImportMaya)
    bpy.utils.register_class(ImportMayaFileHandler)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    logger.info("Maya Import/Export Addon registered successfully with new features.")

def unregister():
    bpy.utils.unregister_class(MayaPreferences)
    bpy.utils.unregister_class(ExportMaya)
    bpy.utils.unregister_class(ImportMaya)
    bpy.utils.unregister_class(InvokeImportMaya)
    bpy.utils.unregister_class(ImportMayaFileHandler)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    logger.info("Maya Import/Export Addon unregistered.")

if __name__ == "__main__":
    # This block is for direct script execution testing (unregister first, then register)
    # try: unregister() except Exception: pass
    # register()
    pass # Standard addons don't run register directly in __main__ typically
